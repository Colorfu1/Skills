# Share-Safe Codex Skills Export

This folder contains sanitized copies of custom Codex skills for sharing/upload.

Included skills:
- job-uploader
- job-manager

Sanitization applied:
- Replaced personal/workspace owner marker `wuwenda` with `owner-tag`

Install on a new machine (manual):
1. Copy each skill folder into `~/.codex/skills/`
2. Start a new Codex session
3. Invoke explicitly (e.g. `$job-uploader`, `$job-manager`)

Example:
```bash
mkdir -p ~/.codex/skills
cp -r job-uploader ~/.codex/skills/
cp -r job-manager ~/.codex/skills/
```
