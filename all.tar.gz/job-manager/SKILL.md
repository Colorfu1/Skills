---
name: job-manager
description: Manage already-submitted Volc ML Platform jobs (`volc ml_task`) including listing tasks, checking status/details, viewing logs, inspecting instances, exporting config/code, monitoring resource usage, and canceling tasks. Use when Codex needs to operate on existing jobs after submission, troubleshoot running/failed jobs, or generate/execute Volc job management commands safely.
---

# Job Manager

## Overview

Use this skill for post-submit job operations on Volc ML Platform custom training tasks.

Focus on safe lifecycle management of existing tasks: inspect, monitor, troubleshoot, export, and cancel only with explicit confirmation.

## Workflow

### 1. Identify the Target Job(s)

Collect or discover the target task before running commands:

- `task_id` (preferred)
- task name (if task ID is unknown)
- instance ID (for logs/top, for example `worker_0`)
- whether the user wants interactive output or machine-readable `json`

If the task ID is unknown, start with `volc ml_task list` (or `--output json`) and filter by name/status.

Workspace preference:

- Default to querying/listing jobs with `Description == "owner-tag"` first when the user asks for "my jobs" or does not specify a task ID.
- Widen the query to all jobs only if the user asks or no matching jobs are found.

### 2. Choose the Operation

Classify the request and choose the smallest command that answers it:

- Status / details: `get`
- Logs: `logs`
- Running tasks overview: `list`
- Resource usage: `top`
- Export config/code: `export`
- Instance details/list: `instance list`
- Stop task: `cancel`

Prefer read-only commands first when debugging.

### 3. Show the Exact Command

Before execution, show the exact `volc ml_task ...` command.

Examples:

- `volc ml_task get --id <task_id> --output json`
- `volc ml_task logs -t <task_id> -i worker_0 -l 200`
- `volc ml_task cancel --id <task_id>`

Use lowercase `json` for `--output json`.

### 4. Confirm Risky Actions

Require explicit confirmation before any command that changes remote state:

- `volc ml_task cancel --id <task_id>`

For read-only commands (`list`, `get`, `logs`, `top`, `export --config`), confirmation is optional unless the user requests it.

### 5. Execute and Return Results

Return concise results:

- For `list/get`: key status fields (`task_id`, name, status, start time, queue)
- For `logs`: the requested lines (or summarized errors if long)
- For `cancel`: success/failure message and task ID
- For `export`: what was exported and where

If running in a restricted sandbox and Volc API calls fail, use approved host/outside-sandbox terminal execution when available.

## Volc Command Map (Post-Submit)

Common `volc ml_task` commands for this skill:

- `list` - list tasks (interactive by default; use `--output json` for parsing)
- `get` - task details
- `logs` - instance logs
- `top` - container load / resource usage
- `cancel` - stop a task
- `export` - export task config and/or code
- `instance list` - list task instances

Use `volc ml_task --help` and subcommand `--help` to confirm flags for the installed CLI version.

## Output Style

When responding to a job-management request, prefer this order:

1. Target task(s) identified
2. Command executed (or planned)
3. Result summary
4. Raw key output lines (if helpful)
5. Next command suggestion (optional, for example `logs` after a failed `get`)

## Safety Rules

- Do not cancel a task unless the user explicitly asks to cancel and confirms the command.
- Do not guess task IDs when multiple matches exist; show candidates and ask which one.
- Prefer `--output json` for automation/parsing.
- If `volc ml_task list` opens an interactive UI unexpectedly, rerun with `--output json`.
- In this workspace, default list/query views to `Description == "owner-tag"` unless the user requests all jobs.

## References

- Read `references/volc-ml-task-job-ops.md` for common command patterns and troubleshooting.
- Read workspace `ml_task.md` for the broader `ml_task` reference (submit + management commands).
